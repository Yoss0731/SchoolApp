﻿using System;

public class Class1
{
	public Class1()
	{
		public int id { get; set; }
	public string name { get; set; }	
	public int lastname { get; set; }
	public int date { get; set; }
	}
}
