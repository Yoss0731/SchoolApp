﻿using System;

namespace School.SL
{
    public class Class1
    {

    }
}
