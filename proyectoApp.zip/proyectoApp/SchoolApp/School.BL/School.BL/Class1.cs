﻿using System;

namespace School.BL
{
    public class Class1
    {

    }
}
