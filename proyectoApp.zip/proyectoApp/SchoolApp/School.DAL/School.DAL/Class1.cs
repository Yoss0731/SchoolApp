﻿using System;

namespace School.DAL
{
    public class Class1
    {

    }
}
